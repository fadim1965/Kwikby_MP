# Kwikby marketplace: design merge

Replace these files in the repository (paths are relative to the project root):

| File | Change |
|---|---|
| Views/Shared/_Layout.cshtml | Header, search with suggestions, categories panel, mega menu, footer restyled with the design. Keeps translations, sign-in state, role links, the cart badge, TempData alerts and the per-shop theme variables. |
| Views/Home/Index.cshtml | Home page with the design's sections, using only real catalogue data. |
| Views/Shared/_KwProductCard.cshtml | New product card in the design style. Used by the home page. The existing _ProductCard is unchanged. |
| Views/Shared/Components/CategoryMenu/Default.cshtml | Replaces the bootstrap dropdown rows with the design's list. The view component code is unchanged. |
| wwwroot/css/kwikby.css | Design system, plus the top bar and main wrapper styles. |
| wwwroot/js/kwikby.js | Adds the suggestion adapter for the catalogue's {products, categories} response. |

The uploaded _Layout_cshtml.css (the .eshop-shell rule) is not used by the merged layout and can be deleted.

## Changes from the design (and why)

- **Hero:** the carousel shows real data only: a welcome slide, the top best seller, and the first featured shop. The fictional shops and campaigns from the design are removed. Campaign slides will come from the hero engine once it is wired into HomeController.
- **Sections:** Hot deals, Most popular, Picked for you and the trust strip. New arrivals, Top shops and Gift guides are removed because the home model has no data for them yet.
- **Picked for you:** the department and sort dropdowns submit to the catalogue, and the chips use filters the catalogue supports (In stock, Top rated, Under 25).
- **Favourites heart:** removed from cards. It needs the wishlist endpoint before it can persist.
- **Mega menu:** Shop new, Shops, Price and Availability link to catalogue sorts and filters that exist. Brands is removed, and Deals is a price sort, not an on-sale filter.
- **Sell:** links to the vendor sign-up page (Vendor area, Onboarding, Register).

## New text to translate

These labels are English in the new markup. Add them to the i18n catalogues before the Arabic and French releases:

Categories, All categories, New arrivals, Deals, Sell, Shop new, Newest first, Best selling, Top rated, Shops, Browse all shops, Price, Lowest prices first, Availability, In stock now, Shop deals, Hot deals, Most popular, More best sellers, Picked for you, Browse all products, All, In stock, Under 25, All departments, Sort by, Showing N products, Welcome to kwikby, Start shopping, Popular right now, Shop spotlight, Visit shop, View product, Tracked delivery, Pay your way, Return requests, Verified reviews, Sell on kwikby, Open a shop, Help, Support.

## Not yet verified

- Nothing has been compiled or rendered. Run `dotnet build` first.
- The right-to-left (Arabic) layout is not tested. The design CSS uses left and right margins that may need mirroring.
- Other pages still use Bootstrap and brand.css, so they will look different from the new header and footer until they are restyled.
